<?php
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>

<button class="grow_skew_forward" style="margin-left: 40%;margin-top: 5%;">Create Resume &rarr;</button>
<frame>
	<?php require 'index.php';?>
	</frame>
	
	



</body>
</html>